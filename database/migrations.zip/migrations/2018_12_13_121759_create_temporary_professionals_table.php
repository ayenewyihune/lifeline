<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTemporaryProfessionalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('temporary_professionals', function (Blueprint $table) {
            $table->increments('id');
            $table->string('first_name');
            $table->string('middle_name');
            $table->string('last_name');
            $table->string('gender');
            $table->date('birth_date');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');

            $table->string('country',20);
            $table->string('region',30);
            $table->string('town',30);
            $table->string('address',50);
            $table->string('phone_number_home',20)->nullable();
            $table->string('phone_number_office',20)->nullable();
            $table->string('phone_number_mobile',20);
            $table->string('website',50)->nullable();

            $table->string('degree_type',20);

            $table->string('study_field',50);

            $table->string('job_title',50);
            $table->string('company',50);

            $table->string('profile_photo',100);
            $table->string('bsc_degree_document',100);
            $table->string('post_full_name');
            $table->string('post_phone_number');
            $table->string('post_town');
            $table->string('post_region');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('temporary_professionals');
    }
}
